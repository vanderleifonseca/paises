﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjetoElp4Paises
{
    public partial class frmCadEstados : ProjetoElp4Paises.frmCadastros
    {
        FrmConsPaises oFrmConsPaises;
        Estados oEstado;
        Controller aCtrl;
        private FrmConsPaises ofrmConsPaises;

        public frmCadEstados()
        {
            InitializeComponent();
        }

        public void setFrmConsPaises(object obj)
        {
            if (obj != null)
            {
                ofrmConsPaises = (FrmConsPaises)obj;
            }
        }
        public override void ConhecaObj(object obj, object ctrl)
        {
            oEstado = (Estados)obj;
            aCtrl = (Controller)ctrl;
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string btnSair = ofrmConsPaises.btnSair.Text;
            ofrmConsPaises.btnSair.Text = "Selecionar";
            ofrmConsPaises.ConhecaObj(oEstado.OPais, aCtrl);
            ofrmConsPaises.ShowDialog();
            this.txtCodigoPais.Text = Convert.ToString(oEstado.OPais.Codigo);
            this.txtPais.Text = oEstado.OPais.Pais.ToString();
            ofrmConsPaises.btnSair.Text = btnSair;
        }

        private void lblCodigo_Click(object sender, EventArgs e)
        {

        }
    }
}
