﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjetoElp4Paises
{
    public partial class frmCadPaises : ProjetoElp4Paises.frmCadastros
    {
        Paises oPais;
        public frmCadPaises()
        {
            InitializeComponent();
        }

        public override void ConhecaObj(object obj, object ctrl)
        {
        }
        protected override void Salvar()
        {
            //if (MessageDlg("Confirma (S/N)") == "S")
            {
                oPais.Codigo = Convert.ToInt32(txtCodigo.Text);
                oPais.Pais = txtPais.Text;
                oPais.Sigla = txtSigla.Text;
                oPais.Ddi = txtDDi.Text;
                oPais.Moeda = txtMoeda.Text;
                //Falta o "aCtrl.Salvar(oPais);
            }
        }
        protected override void CarregaTxt()
        {
            this.txtCodigo.Text = Convert.ToString(oPais.Codigo);
            this.txtPais.Text   = oPais.Pais;
            this.txtSigla.Text  = oPais.Sigla;
            this.txtDDi.Text    = oPais.Ddi;
        }
        protected override void LimpaTxt()
        {
            this.txtCodigo.Text = "0";
            this.txtPais.Clear();
            this.txtSigla.Clear();
            this.txtDDi.Clear();
            this.txtMoeda.Clear();
        }
        protected override void BloquearTxt()
        {
            this.txtPais.Enabled  = false;
            this.txtSigla.Enabled = false;
            this.txtDDi.Enabled   = false;
            this.txtMoeda.Enabled = false;
        }
        protected override void DesbloquearTxt()
        {
            this.txtPais.Enabled  = true;
            this.txtSigla.Enabled = true;
            this.txtDDi.Enabled   = true;
            this.txtMoeda.Enabled = true;
        }

        private void txtSigla_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDDi_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMoeda_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPais_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblMoeda_Click(object sender, EventArgs e)
        {

        }

        private void lblDdi_Click(object sender, EventArgs e)
        {

        }

        private void lblSigla_Click(object sender, EventArgs e)
        {

        }

        private void lblPais_Click(object sender, EventArgs e)
        {

        }
    }
}
