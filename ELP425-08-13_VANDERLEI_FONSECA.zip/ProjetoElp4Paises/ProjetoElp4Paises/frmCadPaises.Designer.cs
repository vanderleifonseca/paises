﻿namespace ProjetoElp4Paises
{
    partial class frmCadPaises
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMoeda = new System.Windows.Forms.TextBox();
            this.txtDDi = new System.Windows.Forms.TextBox();
            this.txtSigla = new System.Windows.Forms.TextBox();
            this.txtPais = new System.Windows.Forms.TextBox();
            this.lblMoeda = new System.Windows.Forms.Label();
            this.lblDdi = new System.Windows.Forms.Label();
            this.lblSigla = new System.Windows.Forms.Label();
            this.lblPais = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtCodigo
            // 
            this.txtCodigo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            // 
            // txtMoeda
            // 
            this.txtMoeda.Location = new System.Drawing.Point(468, 52);
            this.txtMoeda.Name = "txtMoeda";
            this.txtMoeda.Size = new System.Drawing.Size(66, 20);
            this.txtMoeda.TabIndex = 25;
            this.txtMoeda.TextChanged += new System.EventHandler(this.txtMoeda_TextChanged);
            // 
            // txtDDi
            // 
            this.txtDDi.Location = new System.Drawing.Point(387, 52);
            this.txtDDi.Name = "txtDDi";
            this.txtDDi.Size = new System.Drawing.Size(66, 20);
            this.txtDDi.TabIndex = 24;
            this.txtDDi.TextChanged += new System.EventHandler(this.txtDDi_TextChanged);
            // 
            // txtSigla
            // 
            this.txtSigla.Location = new System.Drawing.Point(306, 52);
            this.txtSigla.Name = "txtSigla";
            this.txtSigla.Size = new System.Drawing.Size(66, 20);
            this.txtSigla.TabIndex = 23;
            this.txtSigla.TextChanged += new System.EventHandler(this.txtSigla_TextChanged);
            // 
            // txtPais
            // 
            this.txtPais.Location = new System.Drawing.Point(223, 52);
            this.txtPais.Name = "txtPais";
            this.txtPais.Size = new System.Drawing.Size(66, 20);
            this.txtPais.TabIndex = 22;
            this.txtPais.TextChanged += new System.EventHandler(this.txtPais_TextChanged);
            // 
            // lblMoeda
            // 
            this.lblMoeda.AutoSize = true;
            this.lblMoeda.Location = new System.Drawing.Point(465, 33);
            this.lblMoeda.Name = "lblMoeda";
            this.lblMoeda.Size = new System.Drawing.Size(46, 15);
            this.lblMoeda.TabIndex = 21;
            this.lblMoeda.Text = "Moeda";
            this.lblMoeda.Click += new System.EventHandler(this.lblMoeda_Click);
            // 
            // lblDdi
            // 
            this.lblDdi.AutoSize = true;
            this.lblDdi.Location = new System.Drawing.Point(384, 33);
            this.lblDdi.Name = "lblDdi";
            this.lblDdi.Size = new System.Drawing.Size(28, 15);
            this.lblDdi.TabIndex = 20;
            this.lblDdi.Text = "DDI";
            this.lblDdi.Click += new System.EventHandler(this.lblDdi_Click);
            // 
            // lblSigla
            // 
            this.lblSigla.AutoSize = true;
            this.lblSigla.Location = new System.Drawing.Point(306, 33);
            this.lblSigla.Name = "lblSigla";
            this.lblSigla.Size = new System.Drawing.Size(35, 15);
            this.lblSigla.TabIndex = 19;
            this.lblSigla.Text = "Sigla";
            this.lblSigla.Click += new System.EventHandler(this.lblSigla_Click);
            // 
            // lblPais
            // 
            this.lblPais.AutoSize = true;
            this.lblPais.Location = new System.Drawing.Point(220, 33);
            this.lblPais.Name = "lblPais";
            this.lblPais.Size = new System.Drawing.Size(31, 15);
            this.lblPais.TabIndex = 18;
            this.lblPais.Text = "Pais";
            this.lblPais.Click += new System.EventHandler(this.lblPais_Click);
            // 
            // frmCadPaises
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtMoeda);
            this.Controls.Add(this.txtDDi);
            this.Controls.Add(this.txtSigla);
            this.Controls.Add(this.txtPais);
            this.Controls.Add(this.lblMoeda);
            this.Controls.Add(this.lblDdi);
            this.Controls.Add(this.lblSigla);
            this.Controls.Add(this.lblPais);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmCadPaises";
            this.Controls.SetChildIndex(this.btnSair, 0);
            this.Controls.SetChildIndex(this.txtCodigo, 0);
            this.Controls.SetChildIndex(this.frmSalvas, 0);
            this.Controls.SetChildIndex(this.lbl_Codigo, 0);
            this.Controls.SetChildIndex(this.lblPais, 0);
            this.Controls.SetChildIndex(this.lblSigla, 0);
            this.Controls.SetChildIndex(this.lblDdi, 0);
            this.Controls.SetChildIndex(this.lblMoeda, 0);
            this.Controls.SetChildIndex(this.txtPais, 0);
            this.Controls.SetChildIndex(this.txtSigla, 0);
            this.Controls.SetChildIndex(this.txtDDi, 0);
            this.Controls.SetChildIndex(this.txtMoeda, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMoeda;
        private System.Windows.Forms.TextBox txtDDi;
        private System.Windows.Forms.TextBox txtSigla;
        private System.Windows.Forms.TextBox txtPais;
        private System.Windows.Forms.Label lblMoeda;
        private System.Windows.Forms.Label lblDdi;
        private System.Windows.Forms.Label lblSigla;
        private System.Windows.Forms.Label lblPais;
    }
}
