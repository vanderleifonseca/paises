﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjetoElp4Paises
{
    public partial class frmCadastros : ProjetoElp4Paises.Frm
    {
        public frmCadastros()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSalvar_(object sender, EventArgs e)
        {
            Salvar();
        }

        protected virtual void Salvar()
        {

        }
        protected virtual void CarregaTxt()
        {

        }
        protected virtual void LimpaTxt()
        {

        }
        protected virtual void BloquearTxt()
        {

        }
        protected virtual void DesbloquearTxt()
        {

        }
    }
}
